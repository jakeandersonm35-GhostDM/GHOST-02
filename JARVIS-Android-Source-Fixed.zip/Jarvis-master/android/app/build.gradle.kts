plugins {
    id("com.android.application")
    // gradle.properties sets android.builtInKotlin=false, so the Kotlin plugin
    // must be applied explicitly (MainActivity.kt and the `kotlin {}` block below
    // depend on it). Its version is declared in settings.gradle.kts.
    id("org.jetbrains.kotlin.android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.privateagent.private_agent"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // Required by flutter_local_notifications (java.time APIs on older devices).
        isCoreLibraryDesugaringEnabled = true
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "com.privateagent.private_agent"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        // minSdk 26: foreground-service types, gesture APIs and notification channels
        // all behave consistently from Android 8.0 upwards.
        minSdk = 26
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            // Signed with the debug key so the APK installs directly (sideloading).
            // Use your own keystore before distributing publicly.
            signingConfig = signingConfigs.getByName("debug")
            // R8 shrinking can strip classes that are only referenced from the
            // manifest or via reflection (Shizuku, overlay service, notifications).
            // Keep it off for a reliable sideloaded build.
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}

dependencies {
    // Required by flutter_local_notifications for java.time support below API 26+.
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}
