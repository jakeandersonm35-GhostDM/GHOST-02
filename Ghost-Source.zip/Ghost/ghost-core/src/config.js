'use strict';
const fs = require('fs');
const path = require('path');

// Minimal .env loader (no dependencies). Real environment variables win.
function loadDotEnv(file) {
  try {
    for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
      if (!m || line.trim().startsWith('#')) continue;
      let v = m[2];
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
      if (process.env[m[1]] === undefined) process.env[m[1]] = v;
    }
  } catch (_) { /* no .env file: fine */ }
}
loadDotEnv(path.join(process.cwd(), '.env'));

const e = (k, d = '') => (process.env[k] === undefined || process.env[k] === '' ? d : process.env[k]);

const cfg = {
  port: parseInt(e('PORT', '8080'), 10),
  dataDir: e('DATA_DIR', path.join(process.cwd(), 'data')),
  publicUrl: e('PUBLIC_URL', '').replace(/\/+$/, ''),
  ghostToken: e('GHOST_TOKEN'),
  ownerName: e('OWNER_NAME', 'Boss'),
  allowCodeRun: e('ALLOW_CODE_RUN', '0') === '1',

  groq: { key: e('GROQ_API_KEY'), base: e('GROQ_BASE_URL', 'https://api.groq.com/openai/v1'), model: e('GROQ_MODEL', 'llama-3.3-70b-versatile') },
  openai: {
    base: e('OPENAI_BASE_URL', 'https://api.openai.com/v1'),
    // Three assistant brains. One key is enough; extra keys are optional.
    keys: [e('OPENAI_API_KEY'), e('OPENAI_API_KEY_2'), e('OPENAI_API_KEY_3')],
    models: [e('OPENAI_MODEL_WRITER', e('OPENAI_MODEL', 'gpt-4o-mini')), e('OPENAI_MODEL_CODER', e('OPENAI_MODEL', 'gpt-4o-mini')), e('OPENAI_MODEL_ANALYST', e('OPENAI_MODEL', 'gpt-4o-mini'))],
  },
  omniroute: { base: e('OMNIROUTE_BASE_URL'), key: e('OMNIROUTE_API_KEY'), model: e('OMNIROUTE_MODEL', 'auto') },
  freellm: { base: e('FREELLM_BASE_URL'), key: e('FREELLM_API_KEY'), model: e('FREELLM_MODEL') },
  agentspace: { base: e('AGENTSPACE_BASE_URL'), key: e('AGENTSPACE_API_KEY'), model: e('AGENTSPACE_MODEL') },
  ollama: { base: e('OLLAMA_BASE_URL', 'http://127.0.0.1:11434/v1'), model: e('OLLAMA_MODEL', 'llama3.2') },
  camel: { enabled: e('CAMEL_ENABLED', '1') === '1', rounds: parseInt(e('CAMEL_ROUNDS', '2'), 10) },

  honcho: { key: e('HONCHO_API_KEY'), base: e('HONCHO_BASE_URL', 'https://api.honcho.dev').replace(/\/+$/, ''), workspace: e('HONCHO_WORKSPACE', 'ghost'), peer: e('HONCHO_PEER', 'owner') },

  google: { id: e('GOOGLE_CLIENT_ID'), secret: e('GOOGLE_CLIENT_SECRET') },
  meta: { id: e('META_APP_ID'), secret: e('META_APP_SECRET'), graph: e('META_GRAPH_VERSION', 'v21.0') },
  whatsapp: { phoneId: e('WHATSAPP_PHONE_NUMBER_ID'), token: e('WHATSAPP_TOKEN') },
  twilio: { sid: e('TWILIO_ACCOUNT_SID'), token: e('TWILIO_AUTH_TOKEN'), from: e('TWILIO_FROM_NUMBER') },
  stripe: { key: e('STRIPE_API_KEY') },
  paystack: { key: e('PAYSTACK_SECRET_KEY') },
};

// Every capability and the env keys it needs. Drives the "what is missing" report.
cfg.requirements = () => ({
  server: { needs: { GHOST_TOKEN: !!cfg.ghostToken, PUBLIC_URL: !!cfg.publicUrl }, note: 'Required: the app logs in with GHOST_TOKEN.' },
  main_brain_groq: { needs: { GROQ_API_KEY: !!cfg.groq.key } },
  assistant_brains_openai: { needs: { OPENAI_API_KEY: !!cfg.openai.keys[0] } },
  omniroute_gateway: { needs: { OMNIROUTE_BASE_URL: !!cfg.omniroute.base }, optional: true },
  free_llm: { needs: { FREELLM_BASE_URL: !!cfg.freellm.base, FREELLM_MODEL: !!cfg.freellm.model }, optional: true },
  agentspace: { needs: { AGENTSPACE_BASE_URL: !!cfg.agentspace.base, AGENTSPACE_MODEL: !!cfg.agentspace.model }, optional: true },
  offline_ollama: { needs: { OLLAMA_BASE_URL: !!process.env.OLLAMA_BASE_URL }, optional: true },
  memory_honcho: { needs: { HONCHO_API_KEY: !!cfg.honcho.key }, optional: true, note: 'Without it Ghost uses a local memory file.' },
  google_youtube_gmail: { needs: { GOOGLE_CLIENT_ID: !!cfg.google.id, GOOGLE_CLIENT_SECRET: !!cfg.google.secret } },
  meta_facebook_instagram: { needs: { META_APP_ID: !!cfg.meta.id, META_APP_SECRET: !!cfg.meta.secret } },
  whatsapp: { needs: { WHATSAPP_PHONE_NUMBER_ID: !!cfg.whatsapp.phoneId, WHATSAPP_TOKEN: !!cfg.whatsapp.token } },
  phone_calls_and_number: { needs: { TWILIO_ACCOUNT_SID: !!cfg.twilio.sid, TWILIO_AUTH_TOKEN: !!cfg.twilio.token } },
  business_revenue: { needs: { STRIPE_API_KEY_or_PAYSTACK_SECRET_KEY: !!(cfg.stripe.key || cfg.paystack.key) }, optional: true },
});

module.exports = cfg;
