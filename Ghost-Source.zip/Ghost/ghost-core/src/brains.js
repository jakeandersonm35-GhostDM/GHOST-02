'use strict';
const cfg = require('./config');

class BrainError extends Error {
  constructor(brain, msg, status) { super(`${brain}: ${msg}`); this.brain = brain; this.status = status; }
}

// One OpenAI-compatible /chat/completions call. Every brain below is just a config for this.
async function complete({ name, base, key, model, messages, maxTokens = 1500, temperature = 0.3, timeoutMs = 45000 }) {
  if (!base) throw new BrainError(name, 'not configured');
  const url = base.replace(/\/+$/, '') + '/chat/completions';
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  let res;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(key ? { Authorization: `Bearer ${key}` } : {}) },
      body: JSON.stringify({ model, messages, max_tokens: maxTokens, temperature, stream: false }),
      signal: ctl.signal,
    });
  } catch (e) {
    const err = new BrainError(name, e.name === 'AbortError' ? 'timed out' : `network error (${e.cause?.code || e.message})`);
    err.network = true;
    throw err;
  } finally { clearTimeout(timer); }
  if (!res.ok) {
    const body = (await res.text()).slice(0, 200);
    throw new BrainError(name, `HTTP ${res.status} ${body}`, res.status);
  }
  const j = await res.json();
  const text = j?.choices?.[0]?.message?.content;
  if (typeof text !== 'string' || !text.trim()) throw new BrainError(name, 'empty reply');
  return text;
}

// ---- Brain registry --------------------------------------------------------
// Online: Groq is the MAIN brain. Three OpenAI assistants: writer, coder, analyst.
// Offline: Ollama, and CAMEL-style role-play running on Ollama.
// Gateways: OmniRoute (OpenAI-compatible router), Free-LLM, Agentspace.
function brainDefs() {
  const viaOmni = !!cfg.omniroute.base;
  const defs = {
    main: {
      label: 'Groq (main)', online: true,
      run: (m, o) => viaOmni && !o.direct
        ? complete({ name: 'main via OmniRoute', base: cfg.omniroute.base, key: cfg.omniroute.key, model: cfg.omniroute.model, messages: m, ...o })
        : complete({ name: 'main (Groq)', base: cfg.groq.base, key: cfg.groq.key, model: cfg.groq.model, messages: m, ...o }),
      ready: () => !!(cfg.groq.key || viaOmni),
    },
    groq_direct: {
      label: 'Groq direct', online: true,
      run: (m, o) => complete({ name: 'Groq', base: cfg.groq.base, key: cfg.groq.key, model: cfg.groq.model, messages: m, ...o }),
      ready: () => !!cfg.groq.key,
    },
  };
  ['writer', 'coder', 'analyst'].forEach((role, i) => {
    const key = cfg.openai.keys[i] || cfg.openai.keys[0];
    defs[role] = {
      label: `OpenAI ${role}`, online: true,
      run: (m, o) => complete({ name: `OpenAI ${role}`, base: cfg.openai.base, key, model: cfg.openai.models[i], messages: m, ...o }),
      ready: () => !!key,
    };
  });
  defs.freellm = { label: 'Free-LLM', online: true, ready: () => !!(cfg.freellm.base && cfg.freellm.model),
    run: (m, o) => complete({ name: 'Free-LLM', base: cfg.freellm.base, key: cfg.freellm.key, model: cfg.freellm.model, messages: m, ...o }) };
  defs.agentspace = { label: 'Agentspace', online: true, ready: () => !!(cfg.agentspace.base && cfg.agentspace.model),
    run: (m, o) => complete({ name: 'Agentspace', base: cfg.agentspace.base, key: cfg.agentspace.key, model: cfg.agentspace.model, messages: m, ...o }) };
  defs.ollama = { label: 'Ollama (offline)', online: false, ready: () => !!cfg.ollama.base,
    run: (m, o) => complete({ name: 'Ollama', base: cfg.ollama.base, key: 'ollama', model: cfg.ollama.model, messages: m, timeoutMs: 120000, ...o }) };
  defs.camel = { label: 'CAMEL role-play (offline)', online: false, ready: () => cfg.camel.enabled && !!cfg.ollama.base, run: (m, o) => camelRolePlay(m, o) };
  return defs;
}

// CAMEL-style two-agent role-play on the local model: an "assistant" agent solves the task,
// a "task-giver" agent critiques it and asks for fixes; repeat, then return the last answer.
// (Native implementation of the CAMEL idea; the camel-ai Python package is not required.)
async function camelRolePlay(messages, opts = {}) {
  const local = (m) => complete({ name: 'CAMEL/Ollama', base: cfg.ollama.base, key: 'ollama', model: cfg.ollama.model, messages: m, timeoutMs: 120000, ...opts });
  const task = messages.filter((m) => m.role !== 'system').map((m) => `${m.role}: ${m.content}`).slice(-6).join('\n');
  const sys = messages.find((m) => m.role === 'system')?.content || '';
  let answer = await local([{ role: 'system', content: `${sys}\nYou are the ASSISTANT agent. Solve the task fully and concretely.` }, { role: 'user', content: task }]);
  for (let i = 0; i < Math.max(0, cfg.camel.rounds - 1); i++) {
    const critique = await local([
      { role: 'system', content: 'You are the TASK-GIVER agent. Review the assistant answer against the task. List concrete problems in at most 3 short bullets, or reply exactly APPROVED.' },
      { role: 'user', content: `TASK:\n${task}\n\nANSWER:\n${answer}` },
    ]);
    if (/^\s*APPROVED/i.test(critique)) break;
    answer = await local([
      { role: 'system', content: `${sys}\nYou are the ASSISTANT agent. Improve your answer using the critique. Output only the final improved answer.` },
      { role: 'user', content: `TASK:\n${task}\n\nYOUR PREVIOUS ANSWER:\n${answer}\n\nCRITIQUE:\n${critique}` },
    ]);
  }
  return answer;
}

// ---- Intent -> specialist (cheap keyword routing, no extra LLM call) --------
function classify(text) {
  const t = text.toLowerCase();
  if (/\b(code|function|bug|script|app|website|game|html|css|javascript|python|flutter|dart|api|debug|refactor)\b/.test(t)) return 'coder';
  if (/\b(contract|agreement|proposal|email|caption|post|script for|write|draft|article|blog|copy)\b/.test(t)) return 'writer';
  if (/\b(revenue|income|profit|analy[sz]e|forecast|budget|compare|metrics|report|plan)\b/.test(t)) return 'analyst';
  return 'main';
}

// Chain of brains to try, in order. `mode`: auto | online | offline | main.
function chainFor(mode, specialty, delegate) {
  const offline = ['ollama', 'camel'];
  if (mode === 'offline') return offline;
  if (mode === 'main') return ['groq_direct', 'main'];
  const first = delegate && specialty !== 'main' ? [specialty, 'main'] : ['main', specialty !== 'main' ? specialty : null];
  const online = [...first, 'writer', 'coder', 'analyst', 'freellm', 'agentspace'].filter(Boolean);
  const seen = new Set();
  const dedup = online.filter((b) => (seen.has(b) ? false : seen.add(b)));
  return mode === 'online' ? dedup : [...dedup, ...offline];
}

// Run the chain; first brain that answers wins. Returns { text, brain, tried[] }.
async function route(messages, { mode = 'auto', delegate = true, specialty, maxTokens, temperature } = {}) {
  const defs = brainDefs();
  const spec = specialty || classify(messages.filter((m) => m.role === 'user').slice(-1)[0]?.content || '');
  const tried = [];
  for (const id of chainFor(mode, spec, delegate)) {
    const b = defs[id];
    if (!b || !b.ready()) { tried.push({ brain: id, skipped: 'not configured' }); continue; }
    try {
      const text = await b.run(messages, { maxTokens, temperature });
      tried.push({ brain: id, ok: true });
      return { text, brain: id, label: b.label, tried, specialty: spec };
    } catch (e) {
      tried.push({ brain: id, error: e.message.slice(0, 160) });
    }
  }
  const err = new Error('All brains failed: ' + tried.map((t) => `${t.brain}=${t.error || t.skipped}`).join('; '));
  err.tried = tried;
  throw err;
}

function brainStatus() {
  const d = brainDefs();
  return Object.fromEntries(Object.entries(d).map(([k, v]) => [k, { label: v.label, configured: v.ready(), online: v.online }]));
}

module.exports = { route, brainStatus, classify, complete };
