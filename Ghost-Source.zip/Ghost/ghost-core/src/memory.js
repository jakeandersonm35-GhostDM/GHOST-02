'use strict';
const cfg = require('./config');
const store = require('./store');
const { route } = require('./brains');

// Long-term memory: Honcho when configured, plus a local file so Ghost still remembers offline.
const local = store.open('memory', { facts: [], turns: 0, log: [] });

async function honcho(method, path, body, timeoutMs = 6000) {
  if (!cfg.honcho.key) return null;
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetch(cfg.honcho.base + path, {
      method, signal: ctl.signal,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${cfg.honcho.key}` },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) return null;
    return await res.json().catch(() => ({}));
  } catch (_) { return null; } finally { clearTimeout(t); }
}

let honchoReady = false;
async function ensureHoncho() {
  if (honchoReady || !cfg.honcho.key) return honchoReady;
  const ws = encodeURIComponent(cfg.honcho.workspace);
  await honcho('POST', '/v3/workspaces', { id: cfg.honcho.workspace });
  await honcho('POST', `/v3/workspaces/${ws}/peers`, { id: cfg.honcho.peer });
  await honcho('POST', `/v3/workspaces/${ws}/peers`, { id: 'ghost' });
  honchoReady = true;
  return true;
}

// What Ghost knows about the owner, as text to prepend to the prompt.
async function recall(query) {
  const parts = [];
  if (local.data.facts.length) parts.push('Known facts about the owner:\n- ' + local.data.facts.slice(-40).join('\n- '));
  if (cfg.honcho.key && query.length > 12) {
    await ensureHoncho();
    const ws = encodeURIComponent(cfg.honcho.workspace);
    const r = await honcho('POST', `/v3/workspaces/${ws}/peers/${encodeURIComponent(cfg.honcho.peer)}/chat`,
      { query: `Briefly: what do you know about this person that is relevant to: "${query.slice(0, 300)}"?` });
    const c = r?.content || r?.response || (typeof r === 'string' ? r : '');
    if (c) parts.push('Long-term memory (Honcho):\n' + String(c).slice(0, 1200));
  }
  return parts.join('\n\n');
}

// Save one exchange (fire and forget) and periodically distil durable facts.
async function remember(sessionId, userText, ghostText) {
  local.data.log.push({ t: Date.now(), u: userText.slice(0, 500), g: ghostText.slice(0, 500) });
  local.data.log = local.data.log.slice(-60);
  local.data.turns++;
  if (cfg.honcho.key) {
    await ensureHoncho();
    const ws = encodeURIComponent(cfg.honcho.workspace);
    const sid = encodeURIComponent(sessionId);
    await honcho('POST', `/v3/workspaces/${ws}/sessions`, { id: sessionId });
    await honcho('POST', `/v3/workspaces/${ws}/sessions/${sid}/messages`, {
      messages: [{ peer_id: cfg.honcho.peer, content: userText }, { peer_id: 'ghost', content: ghostText }],
    });
  }
  if (local.data.turns % 6 === 0) await distil().catch(() => {});
  local.save();
}

// "Learn who I am": every 6 turns, extract durable facts/preferences from recent chat.
async function distil() {
  const recent = local.data.log.slice(-12).map((x) => `User: ${x.u}\nGhost: ${x.g}`).join('\n');
  const { text } = await route([
    { role: 'system', content: 'Extract durable facts about the USER (name, business, goals, preferences, people, habits) from the chat. Reply with a JSON array of short strings. Reply [] if none. No prose.' },
    { role: 'user', content: recent },
  ], { delegate: false, maxTokens: 400, temperature: 0 });
  const m = text.match(/\[[\s\S]*\]/);
  if (!m) return;
  for (const f of JSON.parse(m[0])) if (typeof f === 'string' && f && !local.data.facts.includes(f)) local.data.facts.push(f.slice(0, 200));
  local.data.facts = local.data.facts.slice(-200);
}

function addFact(f) { if (f && !local.data.facts.includes(f)) { local.data.facts.push(f.slice(0, 200)); local.save(); } }
function facts() { return local.data.facts; }
function forget(i) { local.data.facts.splice(i, 1); local.save(); }

module.exports = { recall, remember, addFact, facts, forget };
