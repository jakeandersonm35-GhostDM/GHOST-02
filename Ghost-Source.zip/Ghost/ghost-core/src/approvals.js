'use strict';
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const cfg = require('./config');
const store = require('./store');
const connectors = require('./connectors');

// The consent gate. Ghost can only PROPOSE outward or self-changing actions.
// They run only when the owner calls approve(id); what runs is exactly what was stored and shown.
const db = store.open('approvals', { items: [] });
const reg = store.open('registry', { agents: {}, skills: {} });

const LOCAL = {
  async 'agent.add'(p) {
    if (!p.name || !p.role) throw new Error('agent.add needs name and role');
    reg.data.agents[p.name] = { role: p.role, prompt: p.prompt || `You are ${p.name}, a specialist agent. ${p.role}`, enabled: true, created: new Date().toISOString() };
    reg.save(); return { agent: p.name };
  },
  async 'agent.remove'(p) { delete reg.data.agents[p.name]; reg.save(); return { removed: p.name }; },
  async 'skill.add'(p) {
    if (!p.name || !p.prompt) throw new Error('skill.add needs name and prompt');
    reg.data.skills[p.name] = { description: p.description || '', prompt: p.prompt }; reg.save(); return { skill: p.name };
  },
  async 'skill.remove'(p) { delete reg.data.skills[p.name]; reg.save(); return { removed: p.name }; },
  async 'code.run'(p) {
    if (!cfg.allowCodeRun) throw new Error('Code running is disabled. Set ALLOW_CODE_RUN=1 on the server to enable it.');
    const lang = { node: ['node', '.js'], python: ['python3', '.py'] }[p.language];
    if (!lang) throw new Error('language must be node or python');
    const dir = path.join(cfg.dataDir, 'sandbox'); fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, crypto.randomBytes(6).toString('hex') + lang[1]);
    fs.writeFileSync(file, p.code);
    return await new Promise((resolve) => {
      // Empty environment: the child never sees API keys. Not a full sandbox: run Ghost as a non-root container user.
      const c = spawn(lang[0], [file], { cwd: dir, env: { PATH: process.env.PATH }, timeout: 20000 });
      let out = '';
      const add = (d) => { if (out.length < 8000) out += d; };
      c.stdout.on('data', add); c.stderr.on('data', add);
      c.on('close', (code) => { fs.rmSync(file, { force: true }); resolve({ exitCode: code, output: out }); });
      c.on('error', (e) => resolve({ error: e.message }));
    });
  },
  async 'contract.save'(p) {
    const dir = path.join(cfg.dataDir, 'contracts'); fs.mkdirSync(dir, { recursive: true });
    const f = path.join(dir, (p.title || 'contract').replace(/[^\w-]+/g, '_') + '-' + Date.now() + '.md');
    fs.writeFileSync(f, p.text); return { saved: f };
  },
};

const ALL = () => ({ ...connectors.actions, ...LOCAL });
const hash = (type, payload) => crypto.createHash('sha256').update(type + JSON.stringify(payload)).digest('hex');

function propose(type, payload, summary, by = 'ghost') {
  if (!ALL()[type]) throw new Error('Unknown action type: ' + type);
  const item = { id: crypto.randomBytes(5).toString('hex'), type, payload, summary: summary || type, by, status: 'pending', hash: hash(type, payload), createdAt: new Date().toISOString() };
  db.data.items.push(item);
  db.data.items = db.data.items.slice(-300);
  db.save();
  return view(item);
}
const view = (i) => ({ id: i.id, type: i.type, summary: i.summary, payload: i.payload, status: i.status, by: i.by, createdAt: i.createdAt, result: i.result, error: i.error });
const list = (status) => db.data.items.filter((i) => !status || i.status === status).map(view);

async function approve(id) {
  const item = db.data.items.find((i) => i.id === id);
  if (!item) throw Object.assign(new Error('No such approval'), { status: 404 });
  if (item.status !== 'pending') throw Object.assign(new Error(`Already ${item.status}`), { status: 409 });
  if (hash(item.type, item.payload) !== item.hash) { item.status = 'rejected'; item.error = 'Payload changed after proposal'; db.save(); throw new Error(item.error); }
  item.status = 'approved'; item.approvedAt = new Date().toISOString(); db.save();
  try { item.result = await ALL()[item.type](item.payload); item.status = 'done'; }
  catch (e) { item.status = 'failed'; item.error = e.message; }
  db.save();
  return view(item);
}
function reject(id) {
  const item = db.data.items.find((i) => i.id === id);
  if (!item) throw Object.assign(new Error('No such approval'), { status: 404 });
  if (item.status === 'pending') { item.status = 'rejected'; db.save(); }
  return view(item);
}

module.exports = { propose, list, approve, reject, registry: reg, types: () => Object.keys(ALL()) };
