'use strict';
const fs = require('fs');
const path = require('path');
const cfg = require('./config');

fs.mkdirSync(cfg.dataDir, { recursive: true });

// Tiny JSON-file store with atomic writes. Files are chmod 600 (they can hold tokens).
function open(name, fallback) {
  const file = path.join(cfg.dataDir, name + '.json');
  let data;
  try { data = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) { data = fallback; }
  return {
    get data() { return data; },
    save() {
      const tmp = file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(data, null, 2), { mode: 0o600 });
      fs.renameSync(tmp, file);
    },
  };
}
module.exports = { open };
