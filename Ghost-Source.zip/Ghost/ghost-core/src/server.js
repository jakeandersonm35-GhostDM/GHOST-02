'use strict';
const http = require('http');
const crypto = require('crypto');
const cfg = require('./config');
const { route, brainStatus } = require('./brains');
const ghost = require('./ghost');
const memory = require('./memory');
const approvals = require('./approvals');
const connectors = require('./connectors');

const state = { running: false, startedAt: null };
const fails = new Map(); // ip -> [timestamps]

const json = (res, code, obj) => { const b = JSON.stringify(obj); res.writeHead(code, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(b) }); res.end(b); };
const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
async function readBody(req) {
  const chunks = []; let n = 0;
  for await (const c of req) { n += c.length; if (n > 2e6) throw Object.assign(new Error('Body too large'), { status: 413 }); chunks.push(c); }
  const s = Buffer.concat(chunks).toString('utf8');
  return s ? JSON.parse(s) : {};
}

function authed(req, ip, tokenFromQuery) {
  if (!cfg.ghostToken) return false;
  const now = Date.now();
  const recent = (fails.get(ip) || []).filter((t) => now - t < 600000);
  if (recent.length >= 20) throw Object.assign(new Error('Too many failed attempts'), { status: 429 });
  const bearer = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const ok = safeEq(tokenFromQuery || bearer, cfg.ghostToken);
  if (!ok) { recent.push(now); fails.set(ip, recent); }
  return ok;
}

function missingReport() {
  const reqs = cfg.requirements();
  const missing = [];
  for (const [cap, r] of Object.entries(reqs)) {
    const absent = Object.entries(r.needs).filter(([, ok]) => !ok).map(([k]) => k);
    if (absent.length) missing.push({ capability: cap, missingKeys: absent, optional: !!r.optional, note: r.note });
  }
  return missing;
}
const status = () => ({
  running: state.running, startedAt: state.startedAt, owner: cfg.ownerName,
  brains: brainStatus(), connections: connectors.connected(), memory: { honcho: !!cfg.honcho.key, localFacts: memory.facts().length },
  missing: missingReport(), pendingApprovals: approvals.list('pending').length, codeRunEnabled: cfg.allowCodeRun,
});

const OAUTH_MAP = { gmail: 'google', youtube: 'google', facebook: 'meta', instagram: 'meta' };

async function handle(req, res) {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  const ip = req.socket.remoteAddress || '?';

  if (req.method === 'GET' && p === '/health') return json(res, 200, { ok: true, name: 'ghost-core' });

  // ---- OAuth (browser flow; the app appends ?t=<token> so strangers cannot link accounts) ----
  let m;
  if (req.method === 'GET' && (m = p.match(/^\/oauth\/(gmail|youtube|facebook|instagram|outlook)\/start$/))) {
    if (!authed(req, ip, url.searchParams.get('t'))) return json(res, 401, { error: 'unauthorized' });
    if (m[1] === 'outlook') return json(res, 501, { error: 'Outlook is not implemented in Ghost Core. Use Gmail.' });
    try { res.writeHead(302, { Location: connectors.oauthStart(OAUTH_MAP[m[1]]) }); return res.end(); }
    catch (e) { return json(res, 400, { error: e.message }); }
  }
  if (req.method === 'GET' && (m = p.match(/^\/oauth\/callback\/(google|meta)$/))) {
    try {
      await connectors.oauthCallback(m[1], url.searchParams.get('code'), url.searchParams.get('state'));
      res.writeHead(200, { 'Content-Type': 'text/html' });
      return res.end('<h2>Ghost: connected.</h2><p>You can close this tab and return to the app.</p>');
    } catch (e) { res.writeHead(400, { 'Content-Type': 'text/html' }); return res.end('<h2>Connection failed</h2><p>' + String(e.message).replace(/[<>]/g, '') + '</p>'); }
  }

  if (!authed(req, ip)) return json(res, 401, { error: 'unauthorized' });
  const body = req.method === 'POST' ? await readBody(req) : {};
  const needRunning = () => { if (!state.running) throw Object.assign(new Error('Ghost is not started. Press START GHOST in the app.'), { status: 409, code: 'ghost_not_started' }); };

  if (p === '/v1/status' && req.method === 'GET') return json(res, 200, status());
  if (p === '/v1/start' && req.method === 'POST') {
    const missing = missingReport().filter((x) => !x.optional);
    const canThink = Object.values(brainStatus()).some((b) => b.configured);
    state.running = true; state.startedAt = new Date().toISOString();
    return json(res, 200, { ...status(), warning: canThink ? undefined : 'No brain is configured yet. Add GROQ_API_KEY (and/or run Ollama) on the server.', requiredMissing: missing });
  }
  if (p === '/v1/stop' && req.method === 'POST') { state.running = false; return json(res, 200, status()); }

  if (p === '/v1/models') return json(res, 200, { object: 'list', data: ['ghost-auto', 'ghost-online', 'ghost-offline', 'ghost-main'].map((id) => ({ id, object: 'model', owned_by: 'ghost' })) });

  // OpenAI-compatible endpoint: the Android app's existing AI layer points straight at this.
  if (p === '/v1/chat/completions' && req.method === 'POST') {
    needRunning();
    const msgs = Array.isArray(body.messages) ? body.messages : [];
    if (!msgs.length) return json(res, 400, { error: 'messages required' });
    const mode = { 'ghost-offline': 'offline', 'ghost-online': 'online', 'ghost-main': 'main' }[body.model] || 'auto';
    const lastUser = [...msgs].reverse().find((x) => x.role === 'user');
    const mem = await memory.recall(String(lastUser?.content || '').slice(0, 300)).catch(() => '');
    const full = mem ? [{ role: 'system', content: 'About the owner:\n' + mem }, ...msgs] : msgs;
    const r = await route(full, { mode, delegate: false, maxTokens: body.max_tokens, temperature: body.temperature });
    if (lastUser && typeof lastUser.content === 'string' && lastUser.content.length < 2000) memory.remember('app', lastUser.content, r.text).catch(() => {});
    const id = 'chatcmpl-' + crypto.randomBytes(8).toString('hex'), created = Math.floor(Date.now() / 1000);
    if (body.stream) {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' });
      const chunk = (delta, fin) => `data: ${JSON.stringify({ id, object: 'chat.completion.chunk', created, model: body.model || 'ghost-auto', choices: [{ index: 0, delta, finish_reason: fin }] })}\n\n`;
      res.write(chunk({ role: 'assistant', content: r.text }, null)); res.write(chunk({}, 'stop')); return res.end('data: [DONE]\n\n');
    }
    return json(res, 200, { id, object: 'chat.completion', created, model: body.model || 'ghost-auto', ghost_brain: r.brain, choices: [{ index: 0, message: { role: 'assistant', content: r.text }, finish_reason: 'stop' }] });
  }

  if (p === '/v1/ghost/chat' && req.method === 'POST') { needRunning(); return json(res, 200, await ghost.chat({ message: String(body.message || ''), session: body.session, mode: body.mode, agent: body.agent, history: body.history || [] })); }

  if (p === '/v1/approvals' && req.method === 'GET') return json(res, 200, { items: approvals.list(url.searchParams.get('status') || undefined).reverse() });
  if ((m = p.match(/^\/v1\/approvals\/([a-f0-9]+)\/(approve|reject)$/)) && req.method === 'POST') return json(res, 200, m[2] === 'approve' ? await approvals.approve(m[1]) : approvals.reject(m[1]));

  if (p === '/v1/revenue' && req.method === 'GET') return json(res, 200, await connectors.revenue(parseInt(url.searchParams.get('days') || '30', 10)));
  if (p === '/v1/income' && req.method === 'POST') { if (!(Number(body.amount) > 0) || !body.source) return json(res, 400, { error: 'source and positive amount required' }); connectors.addIncome({ source: body.source, amount: Number(body.amount), currency: body.currency || 'USD', note: body.note }); return json(res, 200, { ok: true }); }
  if (p === '/v1/inbox' && req.method === 'GET') return json(res, 200, { unread: await connectors.inboxSummary() });

  if (p === '/v1/agents' && req.method === 'GET') return json(res, 200, { agents: approvals.registry.data.agents, skills: approvals.registry.data.skills });
  if (p === '/v1/agents' && req.method === 'POST') { return json(res, 200, await approvals.propose('agent.add', { name: body.name, role: body.role, prompt: body.prompt }, `Add business agent "${body.name}": ${body.role}`, 'owner')); }
  if ((m = p.match(/^\/v1\/agents\/([\w-]+)\/run$/)) && req.method === 'POST') { needRunning(); return json(res, 200, await ghost.chat({ message: String(body.task || ''), agent: m[1], session: 'agent-' + m[1], mode: body.mode })); }

  if (p === '/v1/contract' && req.method === 'POST') {
    needRunning();
    const prompt = `Draft a ${body.kind || 'service'} contract.\nParties: ${body.parties || 'TBD'}\nKey terms: ${body.terms || 'TBD'}\nJurisdiction: ${body.jurisdiction || 'unspecified'}\nUse clear numbered clauses (scope, payment, term, IP, confidentiality, liability, termination, governing law, signatures). Start with "DRAFT - not legal advice; have a qualified lawyer review before signing."`;
    const r = await route([{ role: 'system', content: 'You are a careful contracts drafter.' }, { role: 'user', content: prompt }], { specialty: 'writer', maxTokens: 3000 });
    const proposal = approvals.propose('contract.save', { title: `${body.kind || 'contract'}`, text: r.text }, 'Save this contract draft to the server', 'ghost');
    return json(res, 200, { draft: r.text, brain: r.brain, approval: proposal });
  }

  if (p === '/v1/memory' && req.method === 'GET') return json(res, 200, { facts: memory.facts() });
  if (p === '/v1/memory' && req.method === 'POST') { memory.addFact(String(body.fact || '')); return json(res, 200, { facts: memory.facts() }); }
  if ((m = p.match(/^\/v1\/memory\/(\d+)$/)) && req.method === 'DELETE') { memory.forget(parseInt(m[1], 10)); return json(res, 200, { facts: memory.facts() }); }
  if (p === '/v1/web/search' && req.method === 'GET') return json(res, 200, { results: await ghost.webSearch(url.searchParams.get('q') || '') });

  return json(res, 404, { error: 'not found' });
}

function createServer() {
  return http.createServer((req, res) => {
    handle(req, res).catch((e) => {
      if (res.headersSent) return res.end();
      const code = e instanceof SyntaxError ? 400 : e.status || (e.tried ? 502 : 500);
      json(res, code, { error: e.message, code: e.code, tried: e.tried });
    });
  });
}

if (require.main === module) {
  if (!cfg.ghostToken || cfg.ghostToken.length < 24) { console.error('Set GHOST_TOKEN (at least 24 random characters) in .env. Generate one: openssl rand -hex 24'); process.exit(1); }
  createServer().listen(cfg.port, () => console.log(`Ghost Core listening on :${cfg.port}`));
}
module.exports = { createServer, state };
