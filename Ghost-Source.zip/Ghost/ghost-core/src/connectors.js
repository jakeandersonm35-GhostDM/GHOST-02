'use strict';
const fs = require('fs');
const crypto = require('crypto');
const cfg = require('./config');
const store = require('./store');

const tokens = store.open('tokens', { google: null, meta: null });
const states = new Map(); // oauth state -> {provider, exp}

async function http(url, { method = 'GET', headers = {}, body, form, timeoutMs = 30000 } = {}) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const opts = { method, headers: { ...headers }, signal: ctl.signal };
    if (form) { opts.body = new URLSearchParams(form).toString(); opts.headers['Content-Type'] = 'application/x-www-form-urlencoded'; }
    else if (body !== undefined) { opts.body = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body); if (!opts.headers['Content-Type']) opts.headers['Content-Type'] = 'application/json'; }
    const res = await fetch(url, opts);
    const txt = await res.text();
    let json; try { json = JSON.parse(txt); } catch (_) { json = { raw: txt.slice(0, 500) }; }
    if (!res.ok) { const e = new Error(`${new URL(url).host} HTTP ${res.status}: ${JSON.stringify(json).slice(0, 300)}`); e.status = res.status; throw e; }
    return json;
  } finally { clearTimeout(t); }
}

// ---------------- OAuth (Google: Gmail + YouTube, Meta: Facebook + Instagram) ----------------
const GOOGLE_SCOPES = [
  'https://www.googleapis.com/auth/gmail.modify',
  'https://www.googleapis.com/auth/youtube.upload',
  'https://www.googleapis.com/auth/youtube.readonly',
  'https://www.googleapis.com/auth/yt-analytics.readonly',
  'https://www.googleapis.com/auth/yt-analytics-monetary.readonly',
];
const META_SCOPES = ['pages_show_list', 'pages_manage_posts', 'pages_read_engagement', 'read_insights', 'instagram_basic', 'instagram_content_publish', 'instagram_manage_insights', 'business_management'];

function oauthStart(provider) {
  const redirect = `${cfg.publicUrl}/oauth/callback/${provider}`;
  const state = crypto.randomBytes(16).toString('hex');
  states.set(state, { provider, exp: Date.now() + 10 * 60 * 1000 });
  if (provider === 'google') {
    if (!cfg.google.id) throw new Error('GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET not set on the server');
    const q = new URLSearchParams({ client_id: cfg.google.id, redirect_uri: redirect, response_type: 'code', scope: GOOGLE_SCOPES.join(' '), access_type: 'offline', prompt: 'consent', state });
    return 'https://accounts.google.com/o/oauth2/v2/auth?' + q;
  }
  if (provider === 'meta') {
    if (!cfg.meta.id) throw new Error('META_APP_ID / META_APP_SECRET not set on the server');
    const q = new URLSearchParams({ client_id: cfg.meta.id, redirect_uri: redirect, scope: META_SCOPES.join(','), response_type: 'code', state });
    return `https://www.facebook.com/${cfg.meta.graph}/dialog/oauth?` + q;
  }
  throw new Error('Unknown provider');
}

async function oauthCallback(provider, code, state) {
  const s = states.get(state);
  states.delete(state);
  if (!s || s.provider !== provider || s.exp < Date.now()) throw new Error('Invalid or expired OAuth state');
  const redirect = `${cfg.publicUrl}/oauth/callback/${provider}`;
  if (provider === 'google') {
    const t = await http('https://oauth2.googleapis.com/token', { method: 'POST', form: { code, client_id: cfg.google.id, client_secret: cfg.google.secret, redirect_uri: redirect, grant_type: 'authorization_code' } });
    tokens.data.google = { access: t.access_token, refresh: t.refresh_token || tokens.data.google?.refresh, exp: Date.now() + (t.expires_in - 60) * 1000 };
  } else {
    const g = `https://graph.facebook.com/${cfg.meta.graph}`;
    const short = await http(`${g}/oauth/access_token?` + new URLSearchParams({ client_id: cfg.meta.id, client_secret: cfg.meta.secret, redirect_uri: redirect, code }));
    const long = await http(`${g}/oauth/access_token?` + new URLSearchParams({ grant_type: 'fb_exchange_token', client_id: cfg.meta.id, client_secret: cfg.meta.secret, fb_exchange_token: short.access_token }));
    const pages = await http(`${g}/me/accounts?` + new URLSearchParams({ fields: 'id,name,access_token,instagram_business_account', access_token: long.access_token }));
    const p = pages.data?.[0];
    if (!p) throw new Error('No Facebook Page found on this account');
    tokens.data.meta = { user: long.access_token, pageId: p.id, pageName: p.name, pageToken: p.access_token, igId: p.instagram_business_account?.id || null };
  }
  tokens.save();
}

async function googleToken() {
  const g = tokens.data.google;
  if (!g) throw new Error('Google is not connected. Use Connections > Gmail/YouTube in the app.');
  if (g.exp > Date.now()) return g.access;
  if (!g.refresh) throw new Error('Google session expired. Reconnect in the app.');
  const t = await http('https://oauth2.googleapis.com/token', { method: 'POST', form: { client_id: cfg.google.id, client_secret: cfg.google.secret, refresh_token: g.refresh, grant_type: 'refresh_token' } });
  g.access = t.access_token; g.exp = Date.now() + (t.expires_in - 60) * 1000; tokens.save();
  return g.access;
}
function meta() { const m = tokens.data.meta; if (!m) throw new Error('Facebook/Instagram is not connected. Use Connections in the app.'); return m; }
const graph = () => `https://graph.facebook.com/${cfg.meta.graph}`;

function connected() {
  return { google: !!tokens.data.google, facebook: !!tokens.data.meta, instagram: !!tokens.data.meta?.igId, whatsapp: !!(cfg.whatsapp.phoneId && cfg.whatsapp.token), twilio: !!(cfg.twilio.sid && cfg.twilio.token) };
}

// ---------------- Outward actions. ONLY called after the owner approves. ----------------
const actions = {
  async 'post.facebook'(p) {
    const m = meta();
    const body = p.imageUrl ? { url: p.imageUrl, caption: p.text, access_token: m.pageToken } : { message: p.text, ...(p.link ? { link: p.link } : {}), access_token: m.pageToken };
    return http(`${graph()}/${m.pageId}/${p.imageUrl ? 'photos' : 'feed'}`, { method: 'POST', body });
  },
  async 'post.instagram'(p) {
    const m = meta();
    if (!m.igId) throw new Error('No Instagram professional account linked to your Facebook Page');
    if (!p.imageUrl && !p.videoUrl) throw new Error('Instagram posts need a public imageUrl or videoUrl');
    const c = await http(`${graph()}/${m.igId}/media`, { method: 'POST', body: { ...(p.videoUrl ? { media_type: 'REELS', video_url: p.videoUrl } : { image_url: p.imageUrl }), caption: p.text, access_token: m.pageToken } });
    for (let i = 0; i < 20 && p.videoUrl; i++) { // wait for video processing
      const s = await http(`${graph()}/${c.id}?fields=status_code&access_token=${m.pageToken}`);
      if (s.status_code === 'FINISHED') break;
      if (s.status_code === 'ERROR') throw new Error('Instagram rejected the video');
      await new Promise((r) => setTimeout(r, 5000));
    }
    return http(`${graph()}/${m.igId}/media_publish`, { method: 'POST', body: { creation_id: c.id, access_token: m.pageToken } });
  },
  async 'post.youtube'(p) {
    const tok = await googleToken();
    let buf;
    if (p.videoPath) buf = fs.readFileSync(p.videoPath);
    else if (p.videoUrl) buf = Buffer.from(await (await fetch(p.videoUrl)).arrayBuffer());
    else throw new Error('YouTube upload needs videoPath (on the server) or videoUrl');
    if (buf.length > 512 * 1024 * 1024) throw new Error('Video larger than 512 MB: not supported here');
    const meta0 = { snippet: { title: p.title || 'Untitled', description: p.text || '', tags: p.tags || [] }, status: { privacyStatus: p.privacy || 'private' } };
    const init = await fetch('https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status', {
      method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json; charset=UTF-8', 'X-Upload-Content-Type': 'video/*', 'X-Upload-Content-Length': String(buf.length) }, body: JSON.stringify(meta0) });
    if (!init.ok) throw new Error('YouTube init failed: ' + (await init.text()).slice(0, 300));
    const up = await fetch(init.headers.get('location'), { method: 'PUT', headers: { 'Content-Type': 'video/*', 'Content-Length': String(buf.length) }, body: buf });
    if (!up.ok) throw new Error('YouTube upload failed: ' + (await up.text()).slice(0, 300));
    const v = await up.json();
    return { id: v.id, url: `https://youtu.be/${v.id}`, privacy: meta0.status.privacyStatus };
  },
  async 'send.whatsapp'(p) {
    if (!cfg.whatsapp.phoneId || !cfg.whatsapp.token) throw new Error('WhatsApp Cloud API keys not set on the server');
    const to = String(p.to).replace(/[^\d]/g, '');
    const body = p.template ? { messaging_product: 'whatsapp', to, type: 'template', template: { name: p.template, language: { code: p.lang || 'en_US' } } } : { messaging_product: 'whatsapp', to, type: 'text', text: { body: p.text } };
    return http(`${graph()}/${cfg.whatsapp.phoneId}/messages`, { method: 'POST', headers: { Authorization: `Bearer ${cfg.whatsapp.token}` }, body });
  },
  async 'send.email'(p) {
    const tok = await googleToken();
    const raw = [`To: ${p.to}`, `Subject: ${p.subject}`, 'MIME-Version: 1.0', 'Content-Type: text/plain; charset=UTF-8', '', p.text].join('\r\n');
    return http('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', { method: 'POST', headers: { Authorization: `Bearer ${tok}` }, body: { raw: Buffer.from(raw).toString('base64url') } });
  },
  async 'call.phone'(p) {
    const tw = cfg.twilio; if (!tw.sid || !tw.token) throw new Error('Twilio keys not set on the server');
    const from = p.from || tw.from; if (!from) throw new Error('No Twilio number yet. Approve "number.provision" first.');
    const say = String(p.say).replace(/[<>&]/g, ' ');
    return http(`https://api.twilio.com/2010-04-01/Accounts/${tw.sid}/Calls.json`, { method: 'POST', headers: { Authorization: 'Basic ' + Buffer.from(`${tw.sid}:${tw.token}`).toString('base64') }, form: { To: p.to, From: from, Twiml: `<Response><Say>${say}</Say></Response>` } });
  },
  async 'number.provision'(p) {
    const tw = cfg.twilio; if (!tw.sid || !tw.token) throw new Error('Twilio keys not set on the server');
    const auth = { Authorization: 'Basic ' + Buffer.from(`${tw.sid}:${tw.token}`).toString('base64') };
    const country = (p.country || 'US').toUpperCase();
    const avail = await http(`https://api.twilio.com/2010-04-01/Accounts/${tw.sid}/AvailablePhoneNumbers/${country}/Local.json?VoiceEnabled=true&SmsEnabled=true&PageSize=1`, { headers: auth });
    const n = avail.available_phone_numbers?.[0];
    if (!n) throw new Error(`Twilio has no local numbers available for ${country}. Try another country.`);
    const bought = await http(`https://api.twilio.com/2010-04-01/Accounts/${tw.sid}/IncomingPhoneNumbers.json`, { method: 'POST', headers: auth, form: { PhoneNumber: n.phone_number } });
    cfg.twilio.from = bought.phone_number;
    const ledger = store.open('number', {}); ledger.data.number = bought.phone_number; ledger.save();
    return { number: bought.phone_number, note: 'Number purchased on your Twilio account (monthly fee applies). WhatsApp needs its own Meta-registered number.' };
  },
};

// ---------------- Read-only: inbox and revenue ----------------
async function inboxSummary(max = 10) {
  const tok = await googleToken();
  const h = { Authorization: `Bearer ${tok}` };
  const list = await http(`https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=${max}&q=is:unread`, { headers: h });
  const out = [];
  for (const m of list.messages || []) {
    const d = await http(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${m.id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject`, { headers: h });
    const hd = Object.fromEntries((d.payload?.headers || []).map((x) => [x.name, x.value]));
    out.push({ id: m.id, from: hd.From, subject: hd.Subject, snippet: d.snippet });
  }
  return out;
}

const ledger = store.open('income', { entries: [] });
function addIncome(e) { ledger.data.entries.push({ ...e, at: new Date().toISOString() }); ledger.save(); }

async function revenue(days = 30) {
  const to = new Date(), from = new Date(Date.now() - days * 864e5);
  const iso = (d) => d.toISOString().slice(0, 10);
  const out = { period: { from: iso(from), to: iso(to) }, sources: {}, notes: [] };
  const attempt = async (key, fn) => { try { out.sources[key] = await fn(); } catch (e) { out.sources[key] = { error: e.message.slice(0, 200) }; } };

  if (tokens.data.google) await attempt('youtube', async () => {
    const tok = await googleToken();
    const r = await http('https://youtubeanalytics.googleapis.com/v2/reports?' + new URLSearchParams({ ids: 'channel==MINE', startDate: iso(from), endDate: iso(to), metrics: 'views,estimatedRevenue' }), { headers: { Authorization: `Bearer ${tok}` } });
    const row = r.rows?.[0] || [0, 0];
    return { views: row[0], estimatedRevenueUSD: row[1], note: 'Needs a monetised channel (YouTube Partner Programme).' };
  });
  if (tokens.data.meta) await attempt('facebook', async () => {
    const m = meta();
    const r = await http(`${graph()}/${m.pageId}/insights?` + new URLSearchParams({ metric: 'page_daily_video_ad_break_earnings', period: 'day', since: iso(from), until: iso(to), access_token: m.pageToken }));
    const vals = r.data?.[0]?.values || [];
    return { earnings: vals.reduce((a, v) => a + (v.value || 0), 0), note: 'In-stream ad earnings only; Meta may not expose this for every Page.' };
  });
  out.sources.instagram = { available: false, note: 'Instagram has no public earnings API. Log income with POST /v1/income so it appears in your totals.' };
  if (cfg.stripe.key) await attempt('stripe', async () => {
    const r = await http(`https://api.stripe.com/v1/balance_transactions?limit=100&created[gte]=${Math.floor(from / 1000)}&type=charge`, { headers: { Authorization: `Bearer ${cfg.stripe.key}` } });
    return { gross: r.data.reduce((a, x) => a + x.amount, 0) / 100, net: r.data.reduce((a, x) => a + x.net, 0) / 100, currency: r.data[0]?.currency, sampled: r.data.length, note: r.has_more ? 'More than 100 charges: first 100 counted.' : undefined };
  });
  if (cfg.paystack.key) await attempt('paystack', async () => {
    const r = await http(`https://api.paystack.co/transaction/totals?from=${iso(from)}&to=${iso(to)}`, { headers: { Authorization: `Bearer ${cfg.paystack.key}` } });
    return { totalVolume: r.data?.total_volume / 100, currencies: r.data?.total_volume_by_currency };
  });
  const manual = ledger.data.entries.filter((e) => new Date(e.at) >= from);
  const sums = {};
  for (const e of manual) sums[e.currency || '?'] = (sums[e.currency || '?'] || 0) + Number(e.amount);
  out.sources.manual_ledger = { entries: manual.length, totals: sums };
  return out;
}

module.exports = { oauthStart, oauthCallback, actions, connected, inboxSummary, revenue, addIncome };
