'use strict';
const cfg = require('./config');
const { route } = require('./brains');
const memory = require('./memory');
const approvals = require('./approvals');

const ACTION_HELP = `To DO something outward or change yourself, you may PROPOSE it with a fenced block. You can never run it; the owner must approve in the app:
\`\`\`ghost-action
{"type":"<type>","summary":"<one plain sentence the owner will read>","payload":{...}}
\`\`\`
Types and payloads:
- post.youtube {title,text,tags[],privacy,videoPath|videoUrl}
- post.instagram {text,imageUrl|videoUrl}
- post.facebook {text,link?,imageUrl?}
- send.email {to,subject,text}
- send.whatsapp {to,text}
- call.phone {to,say}
- number.provision {country}
- agent.add {name,role,prompt} / agent.remove {name}
- skill.add {name,description,prompt} / skill.remove {name}
- code.run {language:"node"|"python",code}
- contract.save {title,text}
Put the exact final wording in payload. Never say something was sent, posted or run until approval is reported to you.`;

function systemPrompt(extra = '') {
  return `You are Ghost, ${cfg.ownerName}'s personal AI assistant and business operator: calm, precise, quietly witty, loyal. Your replies are spoken aloud, so keep them short and natural unless asked for detail (code and documents may be long). Address the owner as "${cfg.ownerName}".
You help run the owner's business, write code/apps/websites/games, draft contracts (always mark them as drafts a qualified lawyer should review), manage content, email and messages, and report income.
${ACTION_HELP}
${extra}`;
}

// ---- web lookup (no API key): DuckDuckGo HTML results ----
async function webSearch(q, n = 5) {
  const res = await fetch('https://html.duckduckgo.com/html/?q=' + encodeURIComponent(q), { headers: { 'User-Agent': 'Mozilla/5.0 GhostCore' }, signal: AbortSignal.timeout(12000) });
  const html = await res.text();
  const out = [];
  const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
  let m;
  while ((m = re.exec(html)) && out.length < n) {
    const strip = (s) => s.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#x27;|&quot;/g, "'").trim();
    let url = m[1]; const u = url.match(/uddg=([^&]+)/); if (u) url = decodeURIComponent(u[1]);
    out.push({ title: strip(m[2]), url, snippet: strip(m[3]) });
  }
  return out;
}
const wantsWeb = (t) => /\b(search|look up|google|latest|news|today|current|price of|who is|what happened)\b/i.test(t);

function extractActions(text) {
  const actions = [];
  const clean = text.replace(/```ghost-action\s*([\s\S]*?)```/g, (_, body) => {
    try { actions.push(JSON.parse(body)); } catch (_) { /* ignore malformed block */ }
    return '';
  }).trim();
  return { clean, actions };
}

async function chat({ message, session = 'main', mode = 'auto', agent, history = [] }) {
  const ag = agent && approvals.registry.data.agents[agent];
  if (agent && !ag) throw Object.assign(new Error('No such agent: ' + agent), { status: 404 });
  const ctxParts = [];
  const mem = await memory.recall(message).catch(() => '');
  if (mem) ctxParts.push(mem);
  let web = [];
  if (mode !== 'offline' && wantsWeb(message)) { web = await webSearch(message).catch(() => []); if (web.length) ctxParts.push('Web results:\n' + web.map((w, i) => `${i + 1}. ${w.title} - ${w.snippet} (${w.url})`).join('\n')); }
  const skills = Object.entries(approvals.registry.data.skills).map(([k, v]) => `- ${k}: ${v.description}`).join('\n');
  if (skills) ctxParts.push('Your learned skills:\n' + skills);

  const messages = [
    { role: 'system', content: systemPrompt((ag ? `You are acting as the business agent "${agent}": ${ag.prompt}\n` : '') + ctxParts.join('\n\n')) },
    ...history.slice(-10).map((h) => ({ role: h.role === 'assistant' ? 'assistant' : 'user', content: String(h.content) })),
    { role: 'user', content: message },
  ];
  const r = await route(messages, { mode });
  const { clean, actions } = extractActions(r.text);
  const proposals = [];
  for (const a of actions) {
    try { proposals.push(approvals.propose(a.type, a.payload || {}, a.summary, agent || 'ghost')); } catch (e) { proposals.push({ error: e.message, type: a.type }); }
  }
  memory.remember(session, message, clean).catch(() => {});
  return { reply: clean || (proposals.length ? 'I have prepared that for your approval.' : ''), brain: r.brain, brainLabel: r.label, tried: r.tried, approvals: proposals, sources: web };
}

module.exports = { chat, webSearch };
