'use strict';
// End-to-end smoke test with mock upstream brains. No internet, no real keys.
const http = require('http');
const assert = require('assert');
const os = require('os');
const path = require('path');
const fs = require('fs');

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ghost-'));
const mock = (name, { fail = false, reply } = {}) => new Promise((resolve) => {
  const calls = [];
  const s = http.createServer((req, res) => {
    let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => {
      calls.push(JSON.parse(b || '{}'));
      if (fail) { res.writeHead(503); return res.end('down'); }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ choices: [{ message: { content: typeof reply === 'function' ? reply(calls[calls.length - 1]) : reply || `reply from ${name}` } }] }));
    });
  }).listen(0, () => resolve({ s, calls, url: `http://127.0.0.1:${s.address().port}/v1` }));
});

(async () => {
  const groq = await mock('groq', { reply: 'Right away, Boss.' });
  const openai = await mock('openai', { reply: (r) => r.messages.some((m) => /post/i.test(m.content)) ? 'Draft ready.\n```ghost-action\n{"type":"post.facebook","summary":"Post hello to your Page","payload":{"text":"Hello world"}}\n```' : 'openai reply' });
  const ollama = await mock('ollama', { reply: 'offline reply' });

  Object.assign(process.env, {
    GHOST_TOKEN: 'x'.repeat(32), DATA_DIR: dataDir, PUBLIC_URL: 'https://ghost.example.com',
    GROQ_API_KEY: 'g', GROQ_BASE_URL: groq.url, OPENAI_API_KEY: 'o', OPENAI_BASE_URL: openai.url, OLLAMA_BASE_URL: ollama.url, OLLAMA_MODEL: 'tiny',
  });
  const { createServer } = require('../src/server');
  const srv = createServer().listen(0);
  const base = `http://127.0.0.1:${srv.address().port}`;
  const H = { Authorization: 'Bearer ' + 'x'.repeat(32), 'Content-Type': 'application/json' };
  const call = async (m, p, body, h = H) => { const r = await fetch(base + p, { method: m, headers: h, body: body ? JSON.stringify(body) : undefined }); return { status: r.status, body: await r.json().catch(() => ({})) }; };

  // 1. auth
  assert.strictEqual((await call('GET', '/v1/status', null, {})).status, 401, 'no token must be rejected');
  // 2. not started yet
  assert.strictEqual((await call('POST', '/v1/ghost/chat', { message: 'hi' })).status, 409, 'chat before Start must be refused');
  // 3. status shows missing keys, never values
  let st = (await call('GET', '/v1/status')).body;
  assert(st.missing.some((m) => m.capability === 'google_youtube_gmail'), 'missing google keys reported');
  assert(!JSON.stringify(st).includes('x'.repeat(32)), 'token must not leak');
  // 4. start
  const start = await call('POST', '/v1/start');
  assert.strictEqual(start.body.running, true);
  // 5. plain chat -> Groq main
  let r = (await call('POST', '/v1/ghost/chat', { message: 'good morning' })).body;
  assert.strictEqual(r.brain, 'main'); assert.strictEqual(r.reply, 'Right away, Boss.');
  // 6. specialist delegation -> OpenAI assistant proposes an action; NOTHING is executed
  r = (await call('POST', '/v1/ghost/chat', { message: 'write a post for facebook' })).body;
  assert.strictEqual(r.brain, 'writer');
  assert.strictEqual(r.approvals.length, 1); assert.strictEqual(r.approvals[0].status, 'pending');
  assert(!r.reply.includes('ghost-action'), 'action block stripped from spoken reply');
  // 7. approve -> executor runs, fails cleanly because Facebook is not connected
  const ap = (await call('POST', `/v1/approvals/${r.approvals[0].id}/approve`)).body;
  assert.strictEqual(ap.status, 'failed'); assert(/not connected/i.test(ap.error));
  // 8. reject path
  r = (await call('POST', '/v1/ghost/chat', { message: 'write a post for facebook again' })).body;
  assert.strictEqual((await call('POST', `/v1/approvals/${r.approvals[0].id}/reject`)).body.status, 'rejected');
  assert.strictEqual((await call('POST', `/v1/approvals/${r.approvals[0].id}/approve`)).status, 409, 'rejected item cannot be approved');
  // 9. OpenAI-compatible endpoint (what the Android app uses)
  const oc = (await call('POST', '/v1/chat/completions', { model: 'ghost-auto', messages: [{ role: 'user', content: 'ping' }] })).body;
  assert.strictEqual(oc.choices[0].message.content, 'Right away, Boss.');
  // 10. fallback: Groq down -> OpenAI assistant takes over
  groq.s.close(); groq.s.closeAllConnections?.();
  r = (await call('POST', '/v1/ghost/chat', { message: 'what is two plus two' })).body;
  assert.notStrictEqual(r.brain, 'main'); assert(['writer', 'coder', 'analyst'].includes(r.brain), 'fell back to an assistant: ' + r.brain);
  // 11. everything online down -> offline Ollama/CAMEL
  openai.s.close(); openai.s.closeAllConnections?.();
  r = (await call('POST', '/v1/ghost/chat', { message: 'hello again' })).body;
  assert(['ollama', 'camel'].includes(r.brain), 'offline brain used: ' + r.brain);
  // 12. forced offline mode via model name, through the OpenAI-compatible route
  const off = (await call('POST', '/v1/chat/completions', { model: 'ghost-offline', messages: [{ role: 'user', content: 'x' }] })).body;
  assert.strictEqual(off.ghost_brain, 'ollama');
  // 13. code.run disabled by default
  const prop = (await call('POST', '/v1/agents', { name: 'sales', role: 'outreach' })).body;
  assert.strictEqual(prop.status, 'pending', 'adding an agent needs approval');
  // 14. stop
  assert.strictEqual((await call('POST', '/v1/stop')).body.running, false);
  console.log('ALL 14 CHECKS PASSED');
  process.exit(0);
})().catch((e) => { console.error('FAIL:', e.message); process.exit(1); });
