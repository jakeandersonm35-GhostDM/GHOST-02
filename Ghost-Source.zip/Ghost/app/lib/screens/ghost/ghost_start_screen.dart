import 'package:flutter/material.dart';

import '../../services/ghost_core_service.dart';
import '../../services/settings_service.dart';
import '../home/home_screen.dart';
import '../settings/connections_screen.dart';

/// The first screen. Enter the server address + token once, then press START GHOST.
class GhostStartScreen extends StatefulWidget {
  const GhostStartScreen({super.key});

  @override
  State<GhostStartScreen> createState() => _GhostStartScreenState();
}

class _GhostStartScreenState extends State<GhostStartScreen> {
  final _settings = SettingsService.instance;
  final _core = GhostCoreService.instance;
  late final TextEditingController _url;
  late final TextEditingController _token;
  bool _busy = false;
  String? _error;
  Map<String, dynamic>? _status;
  List<Map<String, dynamic>> _approvals = [];

  @override
  void initState() {
    super.initState();
    _url = TextEditingController(text: _settings.ghostUrl);
    _token = TextEditingController(text: _settings.ghostToken);
    if (_core.configured) _refresh();
  }

  @override
  void dispose() {
    _url.dispose();
    _token.dispose();
    super.dispose();
  }

  Future<void> _saveCreds() async {
    await _settings.setGhostUrl(_url.text);
    await _settings.setGhostToken(_token.text);
  }

  Future<void> _refresh() async {
    try {
      final s = await _core.status();
      final a = await _core.pendingApprovals();
      if (mounted) setState(() { _status = s; _approvals = a; _error = null; });
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  Future<void> _start() async {
    setState(() { _busy = true; _error = null; });
    try {
      await _saveCreds();
      final r = await _core.start();
      if (!mounted) return;
      setState(() => _status = r);
      final warn = r['warning'] as String?;
      if (warn != null) {
        setState(() => _error = warn);
      } else {
        // The app root switches to the Ghost home screen by itself once started.
        await _refresh();
      }
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _stop() async {
    await _core.stop();
    if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
    await _refresh();
  }

  Future<void> _decide(String id, bool approve) async {
    try {
      final r = approve ? await _core.approve(id) : await _core.reject(id);
      if (mounted && r['status'] == 'failed') {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed: ${r['error']}')));
      } else if (mounted && approve) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Done.')));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final running = _status?['running'] == true;
    final missing = ((_status?['missing'] as List?) ?? const []).cast<Map<String, dynamic>>();
    final brains = ((_status?['brains'] as Map?) ?? const {}).cast<String, dynamic>();
    return Scaffold(
      appBar: AppBar(title: const Text('Ghost'), actions: [
        IconButton(icon: const Icon(Icons.refresh), onPressed: _refresh),
        IconButton(
          icon: const Icon(Icons.link),
          tooltip: 'Connections',
          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ConnectionsScreen())),
        ),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: _url, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Ghost server address', hintText: 'https://ghost.yourdomain.com')),
        const SizedBox(height: 10),
        TextField(controller: _token, obscureText: true, decoration: const InputDecoration(labelText: 'Ghost token (GHOST_TOKEN from your server)')),
        const SizedBox(height: 18),
        SizedBox(
          height: 72,
          child: FilledButton.icon(
            onPressed: _busy ? null : (running ? _stop : _start),
            icon: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : Icon(running ? Icons.stop_circle_outlined : Icons.power_settings_new, size: 30),
            label: Text(running ? 'STOP GHOST' : 'START GHOST', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
          ),
        ),
        if (running) ...[
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const HomeScreen())),
            icon: const Icon(Icons.mic),
            label: const Text('Open Ghost'),
          ),
        ],
        if (_error != null) Card(color: theme.colorScheme.errorContainer, margin: const EdgeInsets.only(top: 12), child: Padding(padding: const EdgeInsets.all(12), child: Text(_error!))),
        if (_approvals.isNotEmpty) ...[
          const SizedBox(height: 20),
          Text('Waiting for your approval', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
          for (final a in _approvals)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${a['summary']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text('${a['type']}  ·  by ${a['by']}', style: theme.textTheme.bodySmall),
                  const SizedBox(height: 6),
                  SelectableText('${a['payload']}', style: theme.textTheme.bodySmall),
                  const SizedBox(height: 8),
                  Row(children: [
                    FilledButton(onPressed: () => _decide('${a['id']}', true), child: const Text('Approve')),
                    const SizedBox(width: 10),
                    OutlinedButton(onPressed: () => _decide('${a['id']}', false), child: const Text('Reject')),
                  ]),
                ]),
              ),
            ),
        ],
        if (_status != null) ...[
          const SizedBox(height: 20),
          Text('Brains', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
          Wrap(spacing: 8, children: [
            for (final e in brains.entries)
              if (e.key != 'groq_direct')
                Chip(
                  avatar: Icon((e.value['configured'] == true) ? Icons.check_circle : Icons.remove_circle_outline, size: 18, color: (e.value['configured'] == true) ? Colors.green : Colors.grey),
                  label: Text('${e.value['label']}'),
                ),
          ]),
          if (missing.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text('Keys still to add on your Huawei server (.env)', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            for (final m in missing)
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(m['optional'] == true ? Icons.info_outline : Icons.warning_amber_rounded, color: m['optional'] == true ? null : Colors.orange),
                title: Text('${m['capability']}'.replaceAll('_', ' ')),
                subtitle: Text((m['missingKeys'] as List).join(', ')),
              ),
          ],
        ],
      ]),
    );
  }
}
