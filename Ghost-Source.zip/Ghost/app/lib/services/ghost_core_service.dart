import 'dart:async';
import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'settings_service.dart';

class GhostCoreException implements Exception {
  final String message;
  final int? status;
  GhostCoreException(this.message, [this.status]);
  @override
  String toString() => message;
}

/// Client for Ghost Core, the server on your Huawei Cloud that holds every API key,
/// runs the brains (Groq, OpenAI, Ollama, CAMEL), keeps long-term memory (Honcho) and
/// owns the approval queue. The phone only stores the server address and one login token.
class GhostCoreService {
  GhostCoreService._();
  static final GhostCoreService instance = GhostCoreService._();

  static const _native = MethodChannel('com.privateagent/accessibility');
  final _settings = SettingsService.instance;
  final _client = http.Client();

  bool get configured => _settings.ghostUrl.isNotEmpty && _settings.ghostToken.isNotEmpty;

  Map<String, String> get _headers => {
        'Authorization': 'Bearer ${_settings.ghostToken}',
        'Content-Type': 'application/json',
      };

  Future<Map<String, dynamic>> _call(String method, String path, [Map<String, dynamic>? body]) async {
    if (!configured) throw GhostCoreException('Enter your Ghost server address and token first.');
    final uri = Uri.parse('${_settings.ghostUrl}$path');
    http.Response res;
    try {
      final req = http.Request(method, uri)..headers.addAll(_headers);
      if (body != null) req.body = jsonEncode(body);
      res = await http.Response.fromStream(await _client.send(req).timeout(const Duration(seconds: 25)));
    } on TimeoutException {
      throw GhostCoreException('Ghost server did not answer in time.');
    } catch (e) {
      throw GhostCoreException('Cannot reach the Ghost server: $e');
    }
    Map<String, dynamic> data;
    try {
      data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      data = {'error': res.body};
    }
    if (res.statusCode == 401) throw GhostCoreException('Wrong token. Check GHOST_TOKEN on the server.', 401);
    if (res.statusCode >= 400) throw GhostCoreException('${data['error'] ?? 'Server error'}', res.statusCode);
    return data;
  }

  Future<Map<String, dynamic>> status() => _call('GET', '/v1/status');

  /// START GHOST: tell the server to go live, point the app's AI layer at it,
  /// and start the keep-alive service so Ghost keeps running with the phone locked.
  Future<Map<String, dynamic>> start() async {
    final result = await _call('POST', '/v1/start');
    final url = _settings.ghostUrl;
    await _settings.setProvider('custom');
    await _settings.setBaseUrl('$url/v1');
    await _settings.setApiKey(_settings.ghostToken);
    await _settings.setModel('ghost-auto');
    // Existing Connections screen + code/publishing features talk to the same server.
    await _settings.setCodeBackendUrl(url);
    await _settings.setCodeBackendApiKey(_settings.ghostToken);
    if (result['warning'] == null) await _settings.setGhostStarted(true);
    try {
      await _native.invokeMethod('startGhostService');
    } catch (_) {/* notification permission or OEM block: Ghost still works in the foreground */}
    return result;
  }

  Future<void> stop() async {
    try {
      await _call('POST', '/v1/stop');
    } finally {
      await _settings.setGhostStarted(false);
      try {
        await _native.invokeMethod('stopGhostService');
      } catch (_) {}
    }
  }

  Future<List<Map<String, dynamic>>> pendingApprovals() async {
    final r = await _call('GET', '/v1/approvals?status=pending');
    return (r['items'] as List).cast<Map<String, dynamic>>();
  }

  Future<Map<String, dynamic>> approve(String id) => _call('POST', '/v1/approvals/$id/approve');
  Future<Map<String, dynamic>> reject(String id) => _call('POST', '/v1/approvals/$id/reject');
  Future<Map<String, dynamic>> revenue({int days = 30}) => _call('GET', '/v1/revenue?days=$days');
}
